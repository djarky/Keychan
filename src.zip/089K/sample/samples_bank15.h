#ifndef SAMPLES_BANK15_H_INCLUDE
#define SAMPLES_BANK15_H_INCLUDE

void play_sample1() __banked;

#endif