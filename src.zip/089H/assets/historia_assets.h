extern const unsigned char zero_tiledata[];
extern const unsigned char one_tiledata[];
extern const unsigned char two_tiledata[];
extern const unsigned char tree_tiledata[];
extern const unsigned char four_tiledata[];
extern const unsigned char five_tiledata[];

extern const unsigned char year20_tiledata[];

extern const unsigned char keychan_title_tiledata[];
extern const unsigned char his_fonts[];
extern const unsigned char splat_fonts[];

extern const unsigned char HIS_tilemap[];

extern const unsigned char big_key_rotacion[];
extern const unsigned char black_bkg_tiledata[];