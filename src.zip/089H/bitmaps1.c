#include"assets/font.c"
#include"assets/doors_rotated.c"