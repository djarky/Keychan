GBTD (Gameboy tile desingner) and GBMB (Gameboy map builder) files
