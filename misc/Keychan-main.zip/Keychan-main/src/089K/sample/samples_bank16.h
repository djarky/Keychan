#ifndef SAMPLES_BANK16_H_INCLUDE
#define SAMPLES_BANK16_H_INCLUDE

void play_sample2() __banked;

#endif