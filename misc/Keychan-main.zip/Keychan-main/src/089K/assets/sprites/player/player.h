extern const unsigned char player_L_frame0[];
extern const unsigned char player_R_frame0[];
extern const unsigned char player_L_walk[];
extern const unsigned char player_R_walk[];