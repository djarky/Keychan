unsigned char col=0x00;
unsigned char row=0x00;


unsigned char map1[90];
unsigned char map2[90];
unsigned char map3[90];
unsigned char map4[90];
unsigned char map5[90];
unsigned char map6[90];
unsigned char map7[90];
unsigned char map8[90];
unsigned char map9[90];


void generateRandomLevel_part(UBYTE map[]);



void generateRandomLevel_room(void);