#include"assets/sprites/player/player.c"
#include"assets/sprites/NPC/mice.c"
#include"assets/bars.c"
#include"assets/title.c"
#include"assets/music_notes.c"

#include"assets/sprites/arrows.c"