


void load_supart_in(UBYTE part[]);
void load_supart_out(UBYTE part[]);

void load_doors_in_map(void);