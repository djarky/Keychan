#include<stdio.h>
#include<gb/gb.h>
#include<stdlib.h>
#include<rand.h>

#include"assets/map/templates.c"

#include"assets/door_map.c"

extern unsigned char temp_ram[];
extern unsigned char temp_ram2[];





#include"assets/map/ladrillos.c"
#include"assets/map/Tiles_maps.c"


#include"assets/PSY_BKG.c"


extern unsigned char hash;

extern unsigned char i;
extern unsigned char k;


#include"mylibs/doors_def.c"

#include"mylibs/draw_door.c"

#include"mylibs/draw_map.c"

#include"mylibs/generator.c"
#include"mylibs/map_manager.c"


#include"mylibs/level_manager.c"

#include"mylibs/doors_manager.c"

