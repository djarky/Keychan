
/*



THIS NOT IS A NPC_CONTROL IS A REDUCED FOR TESTING



*/




unsigned char npc_index=0x00;

#define first_npc_oam 8









unsigned char npc_pos_x[6];
unsigned char npc_pos_y[6];
unsigned char npc_rot[]={J_UP,J_DOWN,J_LEFT,J_RIGHT,J_UP,J_UP};



//platform moves 
#define BACK_WAY  J_LEFT
#define FRONT_WAY J_RIGHT
#define DEAD_WAY  0xFF
unsigned char npc_dir[]={BACK_WAY,BACK_WAY,BACK_WAY,BACK_WAY,BACK_WAY,BACK_WAY};


unsigned char npc_pos_x_abs[]={32,32,80,80};
unsigned char npc_pos_y_abs[]={32,40,64,80};


#define MAP_WHITH 10
#define npc_pos_xy (npc_pos_y[npc_index]*MAP_WHITH)+npc_pos_x[npc_index]
#define TILE_SOLID 0x01





unsigned char npc_joy=0;
unsigned char npc_col=0;



int npc_sprite_cal(){
return first_npc_oam+(npc_index*4);
}


void npc_calcule_xy(){

if(npc_pos_x_abs[npc_index]%16==0){
npc_pos_x[npc_index]=(npc_pos_x_abs[npc_index]/16);
}
if(npc_pos_y_abs[npc_index]%16==0){
npc_pos_y[npc_index]=(npc_pos_y_abs[npc_index]/16);
}


}







//--scroll 

void npc_scrollex(BYTE x_pos,BYTE y_pos){
for(k=0;k<4;k++){scroll_sprite(npc_sprite_cal()+k,x_pos,y_pos);}
npc_pos_x_abs[npc_index]+=x_pos;
npc_pos_y_abs[npc_index]+=y_pos;
}








void init_all_npc(){
for(npc_index=0;npc_index<4;npc_index++){
delay(100);
}
npc_index=0;
}






/*----spawn-------*/

/*
void npc_spawn(UBYTE mapa[]){
npc_index=0;
for(i=0;i<90;i++){
 if(mapa[i]==0x02){
	npc_dir[npc_index]=FRONT_WAY;
	npc_pos_x_abs[npc_index]=(i%MAP_WHITH)*16;
	npc_pos_y_abs[npc_index]=(i/MAP_WHITH)*16;
	npc_index++;
	mapa[i]=0x00;
 }
}
init_all_npc();
}
*/


void npc_spawn(UBYTE mapa[]){
npc_index=0;
for(i=0;i<90;i++){
 if(mapa[i]==0x02){
	npc_dir[npc_index]=FRONT_WAY;
	npc_pos_x_abs[npc_index]=(i%MAP_WHITH)*16;
	npc_pos_y_abs[npc_index]=(i/MAP_WHITH)*16;
	npc_index++;
	mapa[i]=0x00;
 }
}

for(npc_index=0;npc_index<4;npc_index++){
npc_dir[npc_index]=FRONT_WAY;
}
npc_pos_x_abs[0]=32; npc_pos_y_abs[0]=16;
npc_pos_x_abs[1]=112;npc_pos_y_abs[1]=16;
npc_pos_x_abs[2]=32; npc_pos_y_abs[2]=112;
npc_pos_x_abs[3]=112;npc_pos_y_abs[3]=112;
init_all_npc();
}






