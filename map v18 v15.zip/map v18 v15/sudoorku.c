
void print_rot(UBYTE rotacion) {
printf("rot:") ;
switch(rotacion){
case J_UP:        printf("U") ; break;
case J_DOWN: printf("D") ; break;
case J_RIGHT: printf("R") ; break;
case J_LEFT:    printf("L") ;  break;
} 
} 



void print_doors(){
HIDE_WIN;SHOW_BKG;
printf("\n");
printf("doors \n");
for(i=0;i<doors_conected;i++){
waitpadup();
printf("\n");
printf("DOOR-- N %u",i);
delay(100);
printf("\n");
printf("in \n");
printf("room: %u",Doors[i].in_door.room_id);
printf("part: %u",Doors[i].in_door.part_id);
printf("\n");
printf("x: %u ",Doors[i].in_door.x_pos);
printf("y: %u ",Doors[i].in_door.y_pos);
print_rot(Doors[i].in_door.rot) ;
printf("\n");
delay(100);
printf("\n");
printf("out \n");
printf("room: %u",Doors[i].out_door.room_id);
printf("part: %u",Doors[i].out_door.part_id);
printf("\n");
printf("x: %u",Doors[i].out_door.x_pos);
printf("y: %u",Doors[i].out_door.y_pos);
print_rot(Doors[i].out_door.rot) ;
printf("\n");
waitpad(J_A);
}

}




unsigned char  sudoku0[9];
unsigned char  sudoku1[9];
unsigned char  sudoku2[9];
unsigned char  sudoku3[9];
unsigned char  sudoku4[9];
unsigned char  sudoku5[9];
unsigned char  sudoku6[9];
unsigned char  sudoku7[9];
unsigned char  sudoku8[9];




void s_load_supart_in(UBYTE part[]){
part[Doors[i].in_door.part_id]=i+0x10;
}

void s_load_supart_out(UBYTE part[]){
part[Doors[i].out_door.part_id]=i+0x10;
}



void load_sudoorku(){
for(i=0;i<9;i++){
sudoku0[i]=0x0D;
sudoku1[i]=0x0D;
sudoku2[i]=0x0D;
sudoku3[i]=0x0D;
sudoku4[i]=0x0D;
sudoku5[i]=0x0D;
sudoku6[i]=0x0D;
sudoku7[i]=0x0D;
sudoku8[i]=0x0D;
}


for(i=0;i<doors_conected;i++){

switch(Doors[i].in_door.room_id){
case 0:s_load_supart_in(sudoku0);break;
case 1:s_load_supart_in(sudoku1);break;
case 2:s_load_supart_in(sudoku2);break;
case 3:s_load_supart_in(sudoku3);break;
case 4:s_load_supart_in(sudoku4);break;
case 5:s_load_supart_in(sudoku5);break;
case 6:s_load_supart_in(sudoku6);break;
case 7:s_load_supart_in(sudoku7);break;
case 8:s_load_supart_in(sudoku8);break;
}
switch(Doors[i].out_door.room_id){
case 0:s_load_supart_out(sudoku0);break;
case 1:s_load_supart_out(sudoku1);break;
case 2:s_load_supart_out(sudoku2);break;
case 3:s_load_supart_out(sudoku3);break;
case 4:s_load_supart_out(sudoku4);break;
case 5:s_load_supart_out(sudoku5);break;
case 6:s_load_supart_out(sudoku6);break;
case 7:s_load_supart_out(sudoku7);break;
case 8:s_load_supart_out(sudoku8);break;
}


}
}


void show_sudoorku(){
set_win_tiles(0,0,3,3,sudoku0);
set_win_tiles(4,0,3,3,sudoku1);
set_win_tiles(8,0,3,3,sudoku2);

set_win_tiles(0,4,3,3,sudoku3);
set_win_tiles(4,4,3,3,sudoku4);
set_win_tiles(8,4,3,3,sudoku5);

set_win_tiles(0,8,3,3,sudoku6);
set_win_tiles(4,8,3,3,sudoku7);
set_win_tiles(8,8,3,3,sudoku8);

SHOW_WIN;
}



void reset_doors(){
for(i=0;i<doors_conected;i++){
Doors[i].in_door.room_id=0;
Doors[i].out_door.room_id=0;
}
for(i=0;i<9;i++){
check_conection[i]=0;
count_doors[i]=0;
}
doors_conected=0;
}

