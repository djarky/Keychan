#include<stdio.h>
#include<gb/gb.h>
#include<gb/drawing.h>
#include<time.h>
#include<stdlib.h>
#include<rand.h>





unsigned char i=0;
unsigned char k=0;





unsigned char player_rot=J_DOWN;
unsigned char player_hp=0x20;


unsigned char temp_ram[360];
unsigned char temp_ram2[360];

#include"mylibs/sound.c"




#include"level.h"


#include"npc_control_r.c"



#include"mylibs/rand_pos.c"
#include"mylibs/doors.c"

#include"mylibs/doors_manager.h"

#include"assets/doors_rotated.h"

#include"sudoorku.c"

void main(){
printf("doors test \n");

create_rand_doors();


SWITCH_ROM_MBC5(4);
set_bkg_data(0,10,Tile_Dat);


DISPLAY_OFF;
HIDE_BKG;
move_win(0,0);
SHOW_WIN;
SHOW_BKG;
DISPLAY_ON;
for(i=0;i<144;i++){scroll_win(0,1);delay(10);wait_vbl_done();}


delay(500);
move_win(0,0);
HIDE_WIN;
HIDE_BKG;

set_bkg_data(0,10,Tile_Dat);

SHOW_BKG;
DISPLAY_ON;
print_doors();
load_sudoorku();
show_sudoorku();
delay(2000);

ENABLE_RAM_MBC5;
SWITCH_ROM_MBC5(4);
generateRandomLevel();

load_doors_in_map();

DISABLE_RAM_MBC5;
draw_map(map5);
SHOW_BKG;
current_map=5;


SWITCH_ROM_MBC5(6);
set_bkg_data(0x80,42,doors_rotated);

while(1){
SWITCH_ROM_MBC5(4);
manage_maps(joypad());
if(joypad()==J_A){load_sudoorku();show_sudoorku();waitpadup();HIDE_WIN;}
if(joypad()==J_B){
HIDE_WIN;
printf("room: %u",current_room);

}
if(joypad()==J_START){print_doors();}
if(joypad()==J_SELECT+J_UP  ){current_room++;load_level(current_room);current_map=5;draw_map(map5);waitpadup();delay(1000);}
if(joypad()==J_SELECT+J_DOWN){current_room--;load_level(current_room);current_map=5;draw_map(map5);waitpadup();delay(1000);}

if(current_room==0||current_room>9){current_room=5;}

}

}