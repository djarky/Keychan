#define MAP_WIDTH 10
#define MAP_HEIGHT 9



unsigned char current_map=5;


void load_map_down(UBYTE mapa[]);
void load_map_right(UBYTE mapa[]);
void load_map_up(UBYTE mapa[]);
void load_map_left(UBYTE mapa[]);




void manage_maps(UBYTE dir);

