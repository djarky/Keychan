

extern const unsigned char Tile_Dat[];
unsigned char hash=0;

void draw_hash(UBYTE X,UBYTE Y,UBYTE U,UBYTE mapa[]);
void calcule_hash(UBYTE U,UBYTE mapa[]);
void draw_map(UBYTE mapa[]);